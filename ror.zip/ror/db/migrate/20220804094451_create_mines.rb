class CreateMines < ActiveRecord::Migration[5.2]
  def change
    create_table :mines do |t|

      t.timestamps
    end
  end
end
