require 'test_helper'

class FriendlyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
