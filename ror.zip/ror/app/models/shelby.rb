class Shelby < ApplicationRecord
end
