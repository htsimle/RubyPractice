class Mine < ApplicationRecord
end
