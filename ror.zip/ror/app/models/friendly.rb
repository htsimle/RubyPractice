class Friendly < ApplicationRecord
end
