class BookController < ApplicationController
end
